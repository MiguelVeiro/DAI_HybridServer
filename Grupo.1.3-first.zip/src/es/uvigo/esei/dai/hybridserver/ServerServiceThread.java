package es.uvigo.esei.dai.hybridserver;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.Socket;
import java.util.Set;
import java.util.UUID;

import es.uvigo.esei.dai.hybridserver.http.HTTPParseException;
import es.uvigo.esei.dai.hybridserver.http.HTTPRequest;
import es.uvigo.esei.dai.hybridserver.http.HTTPResponse;
import es.uvigo.esei.dai.hybridserver.http.HTTPResponseStatus;

public class ServerServiceThread implements Runnable {

	private Socket socket;
	private HTMLController contentProvider;

	public ServerServiceThread(Socket socket, HTMLController contentProvider) {
		this.socket = socket;
		this.contentProvider = contentProvider;
	}

	public void run() {
		// Atender al cliente
		try (Socket socket = this.socket) {
			// Responder al cliente
			int port = socket.getLocalPort();
			
			HTTPRequest request;
			HTTPResponse response = new HTTPResponse();

			StringBuilder stringBuilder = new StringBuilder();

			BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));

			OutputStream output = socket.getOutputStream();

			try {
				request = new HTTPRequest(reader);
				System.out.println(request.toString());

				switch (request.getMethod()) {
				case GET:

					if (request.getResourceName().equals("html")) {

						if (request.getResourceChain().equals("/html")) {
							stringBuilder.append("<!DOCTYPE html>" + "<html lang=\"es\">" + "<head>"
									+ "  <meta charset=\"utf-8\"/>" + "  <title>Hybrid Server</title>"
									+ "  <link href=\"style.css\" rel=\"stylesheet\" />" + "</head>" + "<body>"
									+ "<h1>Hybrid Server</h1>" + "<ol>");
							for (String set : contentProvider.list()) {
								stringBuilder.append("<li><a href=\"http://localhost:" + port + "/html?uuid=" + set + "\">"
										+ set + "</a></li>");
							}
							stringBuilder.append("</ol>\n" + "</body>" + "</html>");

							response.setStatus(HTTPResponseStatus.S200);
							response.setContent(stringBuilder.toString());

						} else {
							String uuid = request.getResourceParameters().get("uuid");
							// Search for valid UUID
							if (contentProvider.contains(uuid)) {
								System.err.println("AAAAAAAAAA");
								response.setStatus(HTTPResponseStatus.S200);
								response.setContent(contentProvider.getContent(uuid));
							} else {
								throw new HTTPParseException("Not Found");
							}

						}

					} else if (request.getResourceChain().equals("/")) {
						
						stringBuilder.append("<!DOCTYPE html>" 
								+ "<html lang=\"es\">" 
								+ "<head>"
								+ "  <meta charset=\"utf-8\"/>" 
								+ "  <title>Hybrid Server</title>"
								+ "  <link href=\"style.css\" rel=\"stylesheet\" />" 
								+ "</head>" 
								+ "<body>"
								+ "<h1>Hybrid Server</h1>"
								+ "Autores: Miguel Veiro Romero, Martín Pereira González."
								+ "</body>" 
								+ "</html>");

						response.setStatus(HTTPResponseStatus.S200);
						response.setContent(stringBuilder.toString());

					} else {						
						throw new HTTPParseException("Bad Request");						
					}

					break;

				case POST:

					if (!request.getResourceParameters().containsKey("html")) {
						throw new HTTPParseException("Bad Request");
					}
					
					UUID uuid = UUID.randomUUID();
					contentProvider.add(uuid.toString(), request.getResourceParameters().get("html"));

					stringBuilder.append("<!DOCTYPE html>" + "<html lang=\"es\">" + "<head>"
							+ "  <meta charset=\"utf-8\"/>" + "  <title>Hybrid Server</title>"
							+ "  <link href=\"style.css\" rel=\"stylesheet\" />" + "</head>" + "<body>"
							+ "<h1>Hybrid Server</h1>" + "<ol>");
					StringBuilder auxStringBuilder = new StringBuilder();
					for (String set : contentProvider.list()) {
						if (set.equals(uuid.toString())) {
							stringBuilder.append("<li><a href=\"html?uuid=" + set + "\">" + set + "</a></li>");
						} else {
							auxStringBuilder.append("<li><a href=\"html?uuid=" + set + "\">" + set + "</a></li>");
						}
					}
					stringBuilder.append(auxStringBuilder);
					stringBuilder.append("</ol>\n" + "</body>" + "</html>");

					response.setStatus(HTTPResponseStatus.S200);
					response.setContent(stringBuilder.toString());

					break;

				case DELETE:
					
					if(!contentProvider.contains(request.getResourceParameters().get("uuid"))) {
						throw new HTTPParseException("Not Found");
					}

					contentProvider.delete(request.getResourceParameters().get("uuid"));

					stringBuilder.append("<!DOCTYPE html>" + "<html lang=\"es\">" + "<head>"
							+ "  <meta charset=\"utf-8\"/>" + "  <title>Hybrid Server</title>"
							+ "  <link href=\"style.css\" rel=\"stylesheet\" />" + "</head>" + "<body>"
							+ "<h1>Hybrid Server</h1>" + "<ol>");
					for (String set : contentProvider.list()) {
						stringBuilder.append("<li><a href=\"html?uuid=" + set + "\">" + set + "</a></li>");
					}
					stringBuilder.append("</ol>\n" + "</body>" + "</html>");

					response.setStatus(HTTPResponseStatus.S200);
					response.setContent(stringBuilder.toString());

					break;

				default:
					break;
				}

			} catch (HTTPParseException e) {
				if (e.getLocalizedMessage().contains("Not Found")) {
					response.setStatus(HTTPResponseStatus.S404);
					response.setContent("Not Found");
					
				} else if (e.getLocalizedMessage().contains("Bad Request")) {
					response.setStatus(HTTPResponseStatus.S400);
					response.setContent("Bad Request");
					
				}
			} catch (Exception e) {
				response.setStatus(HTTPResponseStatus.S500);
				response.setContent("Internal Server Error");
				e.printStackTrace();
			}

			System.out.println("------------");
			System.out.println(response.toString());
			System.out.println("------------");

			output.write(response.toString().getBytes());
			// output.write(stringBuilder.toString().getBytes());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
